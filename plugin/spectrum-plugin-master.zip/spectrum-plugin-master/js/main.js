// Document Ready

$(document).ready(function(){
	$('.header').spectrum();
});